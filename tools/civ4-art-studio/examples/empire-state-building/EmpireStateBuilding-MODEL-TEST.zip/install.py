"""Install into a COPY of Rise of Mankind. Python 3, no extra packages."""
from pathlib import Path
import argparse, hashlib, json, shutil, datetime, xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def prepare(root):
 m=json.loads((P/'manifest.json').read_text());changes=[]
 for e in m['xml']:
  target=root/e['path'];raw=target.read_bytes()
  if sha(raw)!=e['sha256']:raise ValueError('Source differs from the checked baseline: '+e['path']+'. No files changed. Rebase the definitions using Art Studio.')
  text=raw.decode('utf-8-sig');entry=(P/e['entry']).read_text(encoding='utf-8');end='</'+e['container']+'>'
  if text.count(end)!=1 or e['id'] in text:raise ValueError('Unexpected XML structure or existing ID: '+e['path'])
  patched=text.replace(end,entry+'\n\t'+end).encode('utf-8');ET.fromstring(patched);changes.append((target,patched,raw))
 for e in m['assets']:
  target=root/e['path'];raw=(P/'patch'/e['path']).read_bytes()
  if target.exists():raise ValueError('Refusing to overwrite existing asset: '+e['path'])
  if sha(raw)!=e['sha256']:raise ValueError('Damaged package: '+e['path'])
  changes.append((target,raw,None))
 return changes
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('mod',type=Path);a.add_argument('--apply',action='store_true',help='Write after all checks; default is check only');args=a.parse_args();root=args.mod.resolve();changes=prepare(root)
 print('Validated',len(changes),'files for',root)
 if not args.apply:print('Check only. Add --apply to install.');return
 backup=root/('EmpireState-backup-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'));backup.mkdir()
 for target,raw,old in changes:
  if old is not None:
   f=backup/target.relative_to(root);f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(old)
 journal=[{'path':t.relative_to(root).as_posix(),'new_sha256':sha(raw),'existed':old is not None} for t,raw,old in changes];(backup/'restore.json').write_text(json.dumps(journal,indent=2))
 written=[]
 try:
  for target,raw,old in changes:target.parent.mkdir(parents=True,exist_ok=True);written.append((target,old));target.write_bytes(raw)
 except Exception:
  for target,old in reversed(written):
   if old is None:target.unlink(missing_ok=True)
   else:target.write_bytes(old)
  raise
 print('Installed. Backup:',backup)
if __name__=='__main__':main()
