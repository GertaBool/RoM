import bpy, math, json
from pathlib import Path
from PIL import Image, ImageDraw
P=Path(__file__).resolve().parent; P.mkdir(exist_ok=True)
im=Image.new('RGBA',(1024,1024),(193,183,157,255)); d=ImageDraw.Draw(im)
for y in range(0,1024,16):
 for x in range(0,768,16):
  d.rectangle((x+5,y+3,x+10,y+12),fill=(44,64,72,255));d.line((x+5,y+3,x+10,y+3),fill=(113,125,125,255))
d.rectangle((768,0,831,1023),fill=(201,190,165));d.rectangle((832,0,927,1023),fill=(117,118,111));d.rectangle((928,0,1023,1023),fill=(159,169,174));im.save(P/'diffuse.png');(P/'diffuse.rgba').write_bytes(im.tobytes())
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
mat=bpy.data.materials.new('Empire limestone and windows');mat.use_nodes=True
nodes=mat.node_tree.nodes;tex=nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(P/'diffuse.png'));mat.node_tree.links.new(tex.outputs['Color'],nodes.get('Principled BSDF').inputs['Base Color']);nodes.get('Principled BSDF').inputs['Roughness'].default_value=.78
parts=[]
def box(w,d,h,z,x=0,y=0,kind='wall'):
 bpy.ops.mesh.primitive_cube_add(size=1,location=(x,y,z+h/2));o=bpy.context.object;o.scale=(w,d,h);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(mat)
 uv=o.data.uv_layers.active
 for f in o.data.polygons:
  for li in f.loop_indices:
   v=o.data.vertices[o.data.loops[li].vertex_index].co
   if abs(f.normal.z)>.5: u,t=.86,.5
   elif kind=='stone':u,t=.79,.5
   elif kind=='steel':u,t=.96,.5
   else:
    q=(v.x+w/2) if abs(f.normal.y)>.5 else (v.y+d/2)
    u=.02+q*.25;t=.02+(v.z+h/2)*.23
   uv.data[li].uv=(u,t)
 parts.append(o)
box(2,1.28,.20,0);box(1.84,1.14,.32,.20);box(1.64,1,.25,.52)
box(1.42,.92,.43,.77);box(1.18,.8,.35,1.20)
box(.98,.7,2.35,1.55)
box(.86,.64,.24,3.9);box(.73,.56,.22,4.14);box(.6,.46,.24,4.36)
box(.49,.38,.10,4.60,kind='stone');box(.38,.32,.24,4.70,kind='steel');box(.24,.23,.22,4.94,kind='steel');box(.13,.13,.30,5.16,kind='steel');box(.045,.045,.52,5.46,kind='steel')
# Vertical limestone piers emphasize the Art Deco shaft.
for x in [-.45,-.30,-.15,0,.15,.30,.45]:
 for y in [-.356,.356]:box(.025,.022,2.34,1.55,x,y,'stone')
for y in [-.29,-.145,0,.145,.29]:
 for x in [-.496,.496]:box(.022,.025,2.34,1.55,x,y,'stone')
bpy.ops.object.select_all(action='DESELECT')
for o in parts:o.select_set(True)
bpy.context.view_layer.objects.active=parts[0];bpy.ops.object.join();o=bpy.context.object;o.name='Empire State Building';bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
o.data.calc_loop_triangles();lines=['# Original stylized Empire State Building; Z up; one material','usemtl empire']
for v in o.data.vertices:lines.append('v '+' '.join(str(vv) for vv in v.co))
for uv in o.data.uv_layers.active.data:lines.append('vt '+' '.join(str(vv) for vv in uv.uv))
for t in o.data.loop_triangles:lines.append('f '+' '.join(f'{o.data.loops[li].vertex_index+1}/{li+1}' for li in t.loops))
(P/'building.obj').write_text('\n'.join(lines)+'\n')
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.use_denoising=False;scene.cycles.samples=32;scene.render.resolution_x=768;scene.render.resolution_y=768;scene.render.resolution_percentage=100
scene.world.color=(.18,.18,.18)
bpy.ops.object.camera_add(location=(9,-13,9));cam=bpy.context.object
from mathutils import Vector
cam.rotation_euler=(Vector((0,0,2.85))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=7.2;scene.camera=cam
for loc,power,size in [((4,-6,10),1700,7),((-5,-2,5),1100,5),((2,5,8),1600,4)]:
 bpy.ops.object.light_add(type='AREA',location=loc);l=bpy.context.object;l.data.energy=power;l.data.shape='DISK';l.data.size=size;l.rotation_euler=(Vector((0,0,3))-l.location).to_track_quat('-Z','Y').to_euler()
scene.render.film_transparent=False;scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.025,.045,.07,1)
scene.view_settings.view_transform='AgX';scene.render.filepath=str(P/'preview.png');bpy.ops.wm.save_as_mainfile(filepath=str(P/'EmpireState.blend'));bpy.ops.render.render(write_still=True)
im=Image.open(P/'preview.png').convert('RGBA').resize((64,64),Image.Resampling.LANCZOS);d=ImageDraw.Draw(im);d.rounded_rectangle((1,1,62,62),radius=5,outline=(191,159,91),width=2);im.save(P/'button.png');(P/'button.rgba').write_bytes(im.tobytes())
print('TRIANGLES',len(o.data.loop_triangles))
